#!/bin/bash
echo "=== Network Check ==="
ping -c 4 8.8.8.8
ping -c 4 google.com